import PhoneVerificationScreen from '@/screens/auth/PhoneVerificationScreen';

export default PhoneVerificationScreen;
