import OtpVerificationScreen from '@/screens/auth/OtpVerificationScreen';

export default OtpVerificationScreen;
