import ForgotPasswordScreen from '@/screens/auth/ForgotPasswordScreen';

export default ForgotPasswordScreen;
