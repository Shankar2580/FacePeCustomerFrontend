import RegisterScreen from '@/screens/auth/RegisterScreen';

export default RegisterScreen;
