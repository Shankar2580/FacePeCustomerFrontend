import LoginScreen from '@/screens/auth/LoginScreen';

export default LoginScreen;
