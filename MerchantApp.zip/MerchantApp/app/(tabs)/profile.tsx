import ProfileScreen from '@/screens/main/ProfileScreen';

export default ProfileScreen;
