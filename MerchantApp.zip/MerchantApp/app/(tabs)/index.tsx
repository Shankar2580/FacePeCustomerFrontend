import HomeScreen from '@/screens/main/HomeScreen';

export default HomeScreen;
