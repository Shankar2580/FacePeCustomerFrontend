import HistoryScreen from '@/screens/main/HistoryScreen';

export default HistoryScreen;
