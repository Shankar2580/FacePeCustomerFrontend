import ScanScreen from '@/screens/main/ScanScreen';

export default ScanScreen;
