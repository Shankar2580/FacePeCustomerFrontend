import OnboardingCompleteScreen from '@/screens/onboarding/OnboardingCompleteScreen';

export default OnboardingCompleteScreen;
